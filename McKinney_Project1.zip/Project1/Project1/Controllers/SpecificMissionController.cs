﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Project1.Controllers
{
    public class SpecificMissionController : Controller
    {
        // GET: SpecificMission
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult SpecificMission(String missionName)
        {
            ViewBag.missionName = missionName;


            if (missionName == "California, San Fernando")
            {
                ViewBag.presName = "President Kim B. Henrie";
                ViewBag.missionAddress = "California San Fernando Mission \n 23504 Lyons Ave, Ste 107 \n Santa Clarita, CA 91321-2530";
                ViewBag.language = "English or Spanish";
                ViewBag.climate = "San Fernando, California, gets 16 inches of rain per year. The US average is 37. Snowfall is 0 inches. The average US city gets 25 inches of snow per year. The number of days with any measurable precipitation is 35.";
                ViewBag.religion = "Catholic";
                ViewBag.symbol = "california.png";

            }
            else if(missionName == "Guatemala, Guatemela City Central"){
                ViewBag.presName = "President Melvin G. Markham";
                ViewBag.missionAddress = "Avenida Reforma 8-60, Zona 9, Oficina 505 Apartado Postal 921-A 01009, Guatemala City Guatemala";
                ViewBag.language = "Spanish";
                ViewBag.climate = "November through to April is the dry season and in the mountainous central region (Guatemala City, Antigua, Lake Atitlan, Chichicastenango, Cobán and the highlands) it is an ideal climate for outdoor pursuits with average temperatures of 18°C (64°F).";
                ViewBag.religion = "Catolico (Catholic)";
                ViewBag.symbol = "guatemala.png";

            }
            else
            {
                ViewBag.presName = "President(e) Robert F. Laney";
                ViewBag.missionAddress = "Calle 72 # 10-07 Oficina 1001 Edificio Liberty Seguros Bogota, Cundinamarca Colombia";
                ViewBag.language = "Spanish";
                ViewBag.climate = "The Climate of Colombia is characterized for being tropical and isothermal as a result of its geographical location near the Equator presenting variations within five natural regions and depending on the altitude, temperature, humidity, winds and rainfall.";
                ViewBag.religion = "Catolico (Catholic)";
                ViewBag.symbol = "columbia.png";

            }


            return View();
        }

        public ActionResult Response(int QuestionNumber)
        {
            if (QuestionNumber.Equals(1))
            {
                ViewBag.question = "How late is too late to talk to my bishop?";
            }
            else if (QuestionNumber.Equals(2))
            {
                ViewBag.question = "Why should I even serve a mission?";
            }
            else if (QuestionNumber.Equals(3))
            {
                ViewBag.question = "Is Disney music appropriate?";
            }
            else if (QuestionNumber.Equals(4))
            {
                ViewBag.question = "What if I don't ever get called as an AP?";
            }
            else if (QuestionNumber.Equals(5))
            {
                ViewBag.question = "What if I have a crush on an hermana (and/or elder)?";
            }

            return View();
        }
    }
}